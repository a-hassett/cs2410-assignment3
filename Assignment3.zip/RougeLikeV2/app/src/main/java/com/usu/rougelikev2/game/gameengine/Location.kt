package com.usu.rougelikev2.game.gameengine

class Location(var x: Float, var y: Float)