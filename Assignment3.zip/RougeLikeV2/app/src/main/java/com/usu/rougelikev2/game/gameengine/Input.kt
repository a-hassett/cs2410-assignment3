package com.usu.rougelikev2.game.gameengine

class Input(var type: Type, var location: Location) {
    enum class Type {
        Touch
    }
}