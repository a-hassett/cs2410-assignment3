package com.usu.rougelikev2.game.gameengine


class Layer {
    var isStatic = false
    var gameObjects = mutableListOf<GameObject>()
}